/*
  ArduCAM.h - Arduino library support for CMOS Image Sensor
  Copyright (C)2011-2013 ArduCAM.com. All right reserved
  
  Basic functionality of this library are based on the demo-code provided by
  ArduCAM.com. You can find the latest version of the library at
  http://www.ArduCAM.com

  Now supported controllers:
		-	OV7670
		-	MT9D111
		-	OV7675
		-	OV2640
		-	OV3640
		-	OV5642
	We will add support for many other sensors in next release.


  If you make any modifications or improvements to the code, I would appreciate
  that you share the code with me so that I might include it in the next release.
  I can be contacted through http://www.ArduCAM.com

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/*------------------------------------
	Revision History:
	2012/09/20 	V1.0.0	by Lee	first release 
	2012/10/23  V1.0.1  by Lee  Resolved some timing issue for the Read/Write Register	
	2012/11/29	V1.1.0	by Lee  Add support for MT9D111 sensor
	2012/12/13	V1.2.0	by Lee	Add support for OV7675 sensor
	2012/12/28  V1.3.0	by Lee	Add support for OV2640,OV3640,OV5642 sensors
	2013/02/26	V2.0.0	by Lee	New Rev.B shield hardware, add support for FIFO control 
															and support Mega1280/2560 boards 
	2013/05/28	V2.1.0	by Lee	Add support all drawing functions derived from UTFT library 															
--------------------------------------*/


#ifndef ArduCAM_H
#define ArduCAM_H

#include "Arduino.h"

/****************************************************/
/* Sensor related definition 												*/
/****************************************************/
#define BMP 	0
#define JPEG	1

#define OV7670	0	
#define MT9D111	1
#define OV7675	2
#define OV5642	3
#define OV3640  4
#define OV2640  5
#define OV9655	6
#define MT9M112	7
#define OV7725	8

#define OV2640_160x120 		0	//160x120
#define OV2640_176x144 		1	//176x144
#define OV2640_320x240 		2	//320x240
#define OV2640_352x288 		3	//352x288
#define OV2640_640x480		4	//640x480
#define OV2640_800x600 		5	//800x600
#define OV2640_1024x768		6	//1024x768
#define OV2640_1280x1024	7	//1280x1024
#define OV2640_1600x1200	8	//1600x1200

/****************************************************/
/* I2C Control Definition 													*/
/****************************************************/
#define I2C_ADDR_8BIT 0
#define I2C_ADDR_16BIT 1
#define I2C_REG_8BIT 0
#define I2C_REG_16BIT 1
#define I2C_DAT_8BIT 0
#define I2C_DAT_16BIT 1

/* Register initialization tables for SENSORs */
/* Terminating list entry for reg */
#define SENSOR_REG_TERM_8BIT                0xFF
#define SENSOR_REG_TERM_16BIT               0xFFFF
/* Terminating list entry for val */
#define SENSOR_VAL_TERM_8BIT                0xFF
#define SENSOR_VAL_TERM_16BIT               0xFFFF

/****************************************************/
/* ArduChip related definition 											*/
/****************************************************/
#define ARDUCHIP_DDR       0x00  //GPIO direction register
#define ARDUCHIP_PORT      0x01  //GPIO output register

#define ARDUCHIP_MODE      0x02  //Mode register
#define MCU2LCD_MODE       0x00
#define CAM2LCD_MODE       0x01
#define LCD2MCU_MODE       0x02

#define ARDUCHIP_TIM       0x03  //Timming control
#define HREF_LEVEL_MASK    0x01  //0 = High active , 1 = Low active
#define VSYNC_LEVEL_MASK   0x02  //0 = High active , 1 = Low active
#define TOUCH_EN_MASK      0x04  //0 = disable, 1 = enable
#define DELAY_MASK         0x08  //0 = no delay, 1 = delay one clock
#define MODE_MASK          0x10  //0 = LCD mode, 1 = FIFO mode

#define ARDUCHIP_FIFO      0x04  //FIFO and I2C control
#define FIFO_CLEAR_MASK    0x01
#define FIFO_START_MASK    0x02
#define RST_I2C_MASK       0x04
#define START_I2C_MASK     0x08


#define ARDUCHIP_PIN       0x80  //GPIO input register

#define ARDUCHIP_TRIG      0x81  //Trigger source
#define VSYNC_MASK         0x01
#define SHUTTER_MASK       0x02
#define ADS_INT_MASK       0x04
#define CAP_DONE_MASK      0x08
#define I2C_ERR_MASK       0x10

#define ARDUCHIP_REV       0x82  //CPLD revision
#define VER_LOW_MASK       0x3F
#define VER_HIGH_MASK      0xC0

/****************************************************/

#define cbi(reg, bitmask) *reg &= ~bitmask
#define sbi(reg, bitmask) *reg |= bitmask
#define pulse_high(reg, bitmask) sbi(reg, bitmask); cbi(reg, bitmask);
#define pulse_low(reg, bitmask) cbi(reg, bitmask); sbi(reg, bitmask);

/****************************************************************/
/* define a structure for sensor register initialization values */
/****************************************************************/
struct sensor_reg {
	unsigned int reg;
	unsigned int val;
};


class ArduCAM
{
	public:
		ArduCAM();
		ArduCAM(byte model,int RS, int WR, int RD, int REG_CS, int FIFO_CS);
		void InitCAM();
		
		void enable_fifo(void);
		void disable_fifo(void);
		void flush_fifo(void);
		void start_capture(void);
		void clear_fifo_flag(void);
		uint8_t read_fifo(void);
		
		uint8_t read_reg(uint8_t addr);
		void write_reg(uint8_t addr, uint8_t data);	
		
		int wrSensorRegs(const struct sensor_reg*);
		int wrSensorRegs8_8(const struct sensor_reg*);
		int wrSensorRegs8_16(const struct sensor_reg*);
		int wrSensorRegs16_8(const struct sensor_reg*);
		int wrSensorRegs16_16(const struct sensor_reg*);
		
		byte wrSensorReg(int regID, int regDat);
		byte wrSensorReg8_8(int regID, int regDat);
		byte wrSensorReg8_16(int regID, int regDat);
		byte wrSensorReg16_8(int regID, int regDat);
		byte wrSensorReg16_16(int regID, int regDat);
		
		byte rdSensorReg8_8(uint8_t regID, uint8_t* regDat);
		byte rdSensorReg16_8(uint16_t regID, uint8_t* regDat);
		
		void OV2640_set_JPEG_size(uint8_t size);
		void OV2640_set_format(byte fmt);
		
	protected:
		volatile uint8_t *P_RS, *P_WR, *P_RD, *P_REG_CS, *P_FIFO_CS;
  	uint8_t B_RS, B_WR, B_RD, B_REG_CS, B_FIFO_CS;
  	byte m_fmt;
		byte sensor_model;
		byte sensor_addr;

};

#endif