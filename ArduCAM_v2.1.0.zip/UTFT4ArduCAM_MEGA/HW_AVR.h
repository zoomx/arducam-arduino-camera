// *** Hardwarespecific functions ***
void UTFT::LCD_Writ_Bus(char VH,char VL, byte mode)
{   
	switch (mode)
	{
	case 1:
//Do not support 1bit mode		
		break;
	case 8:
#if defined(__AVR_ATmega1280__) || defined(__AVR_ATmega2560__)
		DDRH = DDRH | 0x18;
		DDRE = DDRE | 0x3B;
		DDRG = DDRG | 0x20;
	
		//PH4 PH3 PE3 PG5 PE5 PE4 PE1 PE0	
		PORTH = ((VH & 0xC0) >> 3);
		PORTE = ((VH & 0x20) >> 2);
		PORTG = ((VH & 0x10) << 1);
		PORTE |= ((VH & 0x0C) << 2);
		PORTE |= ((VH & 0x03));
		pulse_low(P_WR, B_WR);
		
		PORTH = ((VL & 0xC0) >> 3);
		PORTE = ((VL & 0x20) >> 2);
		PORTG = ((VL & 0x10) << 1);
		PORTE |= ((VL & 0x0C) << 2);
		PORTE |= ((VL & 0x03));
		pulse_low(P_WR, B_WR);
#else
		DDRD = 0xFF;
		PORTD = VH;
		pulse_low(P_WR, B_WR);
		PORTD = VL;
		pulse_low(P_WR, B_WR);
#endif
		break;
	case 16:
//Do not support 16bit mode
		break;
	}
}

//Add support for Mega board 20130114
void UTFT::LCD_Read_Bus(char* VH, char* VL)
{   
#if defined(__AVR_ATmega1280__) || defined(__AVR_ATmega2560__)
	*P_RS |= B_RS;
	*P_WR |= B_WR;	//Disable the Write signal
	
	DDRH = (DDRH | 0x18) ^ 0x18;
	DDRE = (DDRE | 0x3B) ^ 0x3B;
	DDRG = (DDRG | 0x20) ^ 0x20;
	*P_RD &= ~B_RD;
	*P_RD &= ~B_RD;	
	//PH4 PH3 PE3 PG5 PE5 PE4 PE1 PE0	
	//*VL = ((PINH & 0x18) << 3) | ((PINE & 0x08) << 2) | ((PING & 0x20) >> 1) | ((PINE & 0x30) >> 2) | (PINE & 0x03) ;
	*VL = ((PINH & 0x18) << 3) | ((PINE & 0x08) << 2) | ((PING & 0x20) >> 1) | ((PINE & 0x30) >> 2) | (PINE & 0x03) ;
	*P_RD |= B_RD;
	
	*P_RD &= ~B_RD;
	*P_RD &= ~B_RD;
	//PH4 PH3 PE3 PG5 PE5 PE4 PE1 PE0	
	//*VH = ((PINH & 0x18) << 3) | ((PINE & 0x08) << 2) | ((PING & 0x20) >> 1) | ((PINE & 0x30) >> 2) | (PINE & 0x03) ;
	*VH = ((PINH & 0x18) << 3) | ((PINE & 0x08) << 2) | ((PING & 0x20) >> 1) | ((PINE & 0x30) >> 2) | (PINE & 0x03) ;
	*P_RD |= B_RD;

#else
	DDRD = 0x00;
	*P_RS |= B_RS;
	*P_WR |= B_WR;	//Disable the Write signal
	
	*P_RD &= ~B_RD;
	*VH = PIND;
	*P_RD |= B_RD;
	
	*P_RD &= ~B_RD;
	*VL = PIND;
	*P_RD |= B_RD;
#endif
}

void UTFT::LCD_Read_Byte(char* val)
{   
#if defined(__AVR_ATmega1280__) || defined(__AVR_ATmega2560__)
	*P_RS |= B_RS;
	*P_RD &= ~B_RD;
	*P_WR |= B_WR;	//Disable the Write signal
	
	DDRH = (DDRH | 0x18) ^ 0x18;
	DDRE = (DDRE | 0x3B) ^ 0x3B;
	DDRG = (DDRG | 0x20) ^ 0x20;
	
	*P_RD &= ~B_RD;
	//PH4 PH3 PE3 PG5 PE5 PE4 PE1 PE0	
	*val = ((PINH & 0x18) << 3) | ((PINE & 0x08) << 2) | ((PING & 0x20) >> 1) | ((PINE & 0x30) >> 2) | (PINE & 0x03) ;
	*P_RD |= B_RD;
	
#else
	DDRD = 0x00;
	*P_RS |= B_RS;
	*P_RD &= ~B_RD;
	*P_WR |= B_WR;	//Disable the Write signal
	*val = PIND;
	*P_RD |= B_RD;
#endif
}

void UTFT::_set_direction_registers(byte mode)
{
#if defined(__AVR_ATmega1280__) || defined(__AVR_ATmega2560__)
	//PH4 PH3 PE3 PG5 PE5 PE4 PE1 PE0	
	DDRH = DDRH | 0x18;
	DDRE = DDRE | 0x3B;
	DDRG = DDRG | 0x20;
#else
	DDRD = 0xFF;
#endif

}
